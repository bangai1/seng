package email;

import java.util.LinkedList;
import java.util.List;

public class ListOfEmails {
	
	private List<Email> emails = new LinkedList<>();

    public void add(Email email) {
        emails.add(email);
    }

    public Email read(int id) {
        for (Email email : emails) {
            if (email.getId() == id) {
                email.markAsRead();
                return email;
            }
        }
        return null;
    }

    public Email delete(int id) {
        Email deletedEmail = null;
        for (Email email : emails) {
            if (email.getId() == id) {
                deletedEmail = email;
                emails.remove(email);
                break;
            }
        }
        return deletedEmail;
    }

    public List<Email> getAllEmails() {
        return emails;
    }

    public List<Email> getUnreadEmails() {
        List<Email> unreadEmails = new LinkedList<>();
        for (Email email : emails) {
            if (!email.isRead()) {
                unreadEmails.add(email);
            }
        }
        return unreadEmails;
    }

}
