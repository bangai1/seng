package email;

import java.util.Stack;
import java.util.Scanner;

	
	
		public class Calc {
		    public static void main(String[] args) {
		        Stack<Integer> stack = new Stack<>();
		        Scanner scanner = new Scanner(System.in);

		        System.out.println("Enter integers and operators in postfix notation (E to exit):");

		        while (scanner.hasNext()) {
		            if (scanner.hasNextInt()) {
		                int operand = scanner.nextInt();
		                stack.push(operand);
		            } else {
		                String operator = scanner.next();
		                if (operator.equals("+")) {
		                    if (stack.size() < 2) {
		                        System.out.println("Error: Not enough operands for +");
		                        return;
		                    }
		                    int operand2 = stack.pop();
		                    int operand1 = stack.pop();
		                    stack.push(operand1 + operand2);
		                } else if (operator.equals("-")) {
		                    if (stack.size() < 2) {
		                        System.out.println("Error: Not enough operands for -");
		                        return;
		                    }
		                    int operand2 = stack.pop();
		                    int operand1 = stack.pop();
		                    stack.push(operand1 - operand2);
		                } else if (operator.equals("*")) {
		                    if (stack.size() < 2) {
		                        System.out.println("Error: Not enough operands for *");
		                        return;
		                    }
		                    int operand2 = stack.pop();
		                    int operand1 = stack.pop();
		                    stack.push(operand1 * operand2);
		                } else if (operator.equals("/")) {
		                    if (stack.size() < 2) {
		                        System.out.println("Error: Not enough operands for /");
		                        return;
		                    }
		                    int operand2 = stack.pop();
		                    int operand1 = stack.pop();
		                    if (operand2 == 0) {
		                        System.out.println("Error: Division by zero");
		                        return;
		                    }
		                    stack.push(operand1 / operand2);
		                } else if (operator.equals("E")) {
		                    if (stack.size() == 1) {
		                        System.out.println("Result is " + stack.pop());
		                    } else {
		                        System.out.println("Error: Invalid expression");
		                    }
		                    break;
		                } else {
		                    System.out.println("Invalid operator: " + operator);
		                    return;
		                }
		            }
		            
			        scanner.close();

		        }

		    }
		}


