package email;
import java.util.List;
import java.util.Scanner;

public class EmailApplication {
	    public static void main(String[] args) {
	        ListOfEmails inbox = new ListOfEmails();
	        ListOfEmails archive = new ListOfEmails();
	        ListOfEmails trash = new ListOfEmails();

	        Scanner scanner = new Scanner(System.in);
	        while (scanner.hasNext()) {
	            String line = scanner.nextLine();
	            String[] parts = line.split(" ");
	            String command = parts[0];

	            switch (command) {
	                case "N":
	                    handleNewEmail(parts, inbox);
	                    break;
	                case "R":
	                    handleReadEmail(parts, inbox);
	                    break;
	                case "A":
	                    handleArchiveEmail(parts, inbox, archive);
	                    break;
	                case "D":
	                    handleDeleteEmail(parts, inbox, trash);
	                    break;
	                case "S":
	                    handleShowFolder(parts, inbox, archive, trash);
	                    break;
	                case "U":
	                    handleShowUnreadEmails(parts, inbox, archive, trash);
	                    break;
	                case "C":
	                    handleClearFolder(parts, inbox, archive, trash);
	                    break;
	                case "E":
	                    scanner.close();
	                    return;
	                default:
	                    System.out.println("Invalid command: " + command);
	            }
	        }
	        
	        scanner.close();
	    }

	    private static void handleNewEmail(String[] parts, ListOfEmails inbox) {
	        if (parts.length < 5) {
	            System.out.println("Invalid input for new email");
	            return;
	        }
	        String subject = parts[1];
	        int id = Integer.parseInt(parts[2]);
	        String message = parts[3];
	        int time = Integer.parseInt(parts[4]);
	        Email email = new Email(subject, id, message, time);
	        inbox.add(email);
	    }

	    private static void handleReadEmail(String[] parts, ListOfEmails inbox) {
	        if (parts.length < 2) {
	            System.out.println("Invalid input for read email");
	            return;
	        }
	        int id = Integer.parseInt(parts[1]);
	        Email email = inbox.read(id);
	        if (email != null) {
	            printEmailDetails(email);
	        } else {
	            System.out.println("No such email.");
	        }
	    }

	    private static void handleArchiveEmail(String[] parts, ListOfEmails inbox, ListOfEmails archive) {
	        if (parts.length < 2) {
	            System.out.println("Invalid input for archive email");
	            return;
	        }
	        int id = Integer.parseInt(parts[1]);
	        Email email = inbox.read(id);
	        if (email != null) {
	            archive.add(email);
	            System.out.println("Email " + id + " archived.");
	        } else {
	            System.out.println("No such email.");
	        }
	    }

	    private static void handleDeleteEmail(String[] parts, ListOfEmails inbox, ListOfEmails trash) {
	        if (parts.length < 2) {
	            System.out.println("Invalid input for delete email");
	            return;
	        }
	        int id = Integer.parseInt(parts[1]);
	        Email email = inbox.delete(id);
	        if (email != null) {
	            trash.add(email);
	            System.out.println("Email " + id + " is deleted.");
	        } else {
	            System.out.println("No such email.");
	        }
	    }

	    private static void handleShowFolder(String[] parts, ListOfEmails inbox, ListOfEmails archive, ListOfEmails trash) {
	        if (parts.length < 2) {
	            System.out.println("Invalid input for show folder");
	            return;
	        }
	        String folder = parts[1];
	        ListOfEmails targetFolder = selectFolder(folder, inbox, archive, trash);
	        if (targetFolder != null) {
	            printEmailList(targetFolder.getAllEmails());
	        } else {
	            System.out.println("Invalid folder.");
	        }
	    }

	    private static void handleShowUnreadEmails(String[] parts, ListOfEmails inbox, ListOfEmails archive, ListOfEmails trash) {
	        if (parts.length < 2) {
	            System.out.println("Invalid input for show unread emails");
	            return;
	        }
	        String folder = parts[1];
	        ListOfEmails targetFolder = selectFolder(folder, inbox, archive, trash);
	        if (targetFolder != null) {
	            printEmailList(targetFolder.getUnreadEmails());
	        } else {
	            System.out.println("Invalid folder.");
	        }
	    }

	    private static void handleClearFolder(String[] parts, ListOfEmails inbox, ListOfEmails archive, ListOfEmails trash) {
	        if (parts.length < 2) {
	            System.out.println("Invalid input for clear folder");
	            return;
	        }
	        String folder = parts[1];
	        ListOfEmails targetFolder = selectFolder(folder, inbox, archive, trash);
	        if (targetFolder != null) {
	            clearFolder(targetFolder, trash);
	        } else {
	            System.out.println("Invalid folder.");
	        }
	    }

	    private static ListOfEmails selectFolder(String folder, ListOfEmails inbox, ListOfEmails archive, ListOfEmails trash) {
	        switch (folder) {
	            case "Inbox":
	                return inbox;
	            case "Archive":
	                return archive;
	            case "Trash":
	                return trash;
	            default:
	                return null;
	        }
	    }

	    private static void clearFolder(ListOfEmails source, ListOfEmails destination) {
	        destination.getAllEmails().addAll(source.getAllEmails());
	        source.getAllEmails().clear();
	        System.out.println("Folder cleared.");
	    }

	    private static void printEmailDetails(Email email) {
	        System.out.println("Email id: " + email.getId());
	        System.out.println("Subject: " + email.getSubject());
	        System.out.println("Body: " + email.getMessage());
	        System.out.println("Time received: " + email.getTime());
	        System.out.println("Status: " + (email.isRead() ? "Read" : "Unread"));
	    }

	    private static void printEmailList(List<Email> emailList) {
	        System.out.println("Email Subject Body Time Read");
	        for (Email email : emailList) {
	            String subject = email.getSubject().length() > 25 ? email.getSubject().substring(0, 25) : email.getSubject();
	            String message = email.getMessage().length() > 40 ? email.getMessage().substring(0, 40) : email.getMessage();
	            System.out.println(email.getId() + " " + subject + " " + message + " " + email.getTime()
	                    + " " + (email.isRead() ? "Yes" : "No"));
	        }
	    }
	}



