package email;

public class Email {
	
	    private String subject;
	    private int id;
	    private String message;
	    private int time;
	    private boolean isRead;

	    public Email(String subject, int id, String message, int time) {
	        this.subject = subject;
	        this.id = id;
	        this.message = message;
	        this.time = time;
	        this.isRead = false;
	    }

	    public String getSubject() {
	        return subject;
	    }

	    public int getId() {
	        return id;
	    }

	    public String getMessage() {
	        return message;
	    }

	    public int getTime() {
	        return time;
	    }

	    public boolean isRead() {
	        return isRead;
	    }

	    public void markAsRead() {
	        isRead = true;
	    }
	}

}
